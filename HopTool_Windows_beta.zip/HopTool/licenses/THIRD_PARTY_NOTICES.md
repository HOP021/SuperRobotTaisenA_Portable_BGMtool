# 同梱しているソフトウェアのライセンス

`SRWAP_BGMtool.apk` には、次のソフトウェアが独立した実行ファイルとして含まれています
（APK 内の `lib/<ABI>/libatracdenc.so` と `lib/<ABI>/libffmpeg.so`）。
どちらも GNU Lesser General Public License v2.1 以降（LGPL-2.1-or-later）で提供されています。
ライセンス全文は LGPL-2.1.txt（この APK の assets/licenses/ 内） にあります。

## atracdenc

- 用途: 音声を ATRAC3 に変換する
- ソース: https://github.com/dcherednik/atracdenc
- 使用したコミット: `cb170709f836cb43dc0312455188c791159d81dc`
- 変更点: libsndfile を使わずに WAV を読み書きする小さなバックエンドを追加しました。
  変更内容はすべて atracdenc-wav-backend.patch（この APK の assets/licenses/ 内） にあります
- ビルド: Android NDK r27c、`-DATRACDENC_PCM_IO_BACKEND=wav -DANDROID_PLATFORM=24 -DANDROID_STL=c++_static`

## FFmpeg

- 用途: ISO / CSO に入っている元の曲（ATRAC3）を再生用に WAV にする
- ソース: https://github.com/FFmpeg/FFmpeg （タグ `n7.1`、変更なし）
- ビルド設定（GPL 部分は含みません）:

```
--target-os=android --enable-cross-compile --enable-small --disable-debug
--disable-everything --disable-autodetect --disable-doc --disable-network
--disable-ffplay --disable-ffprobe
--enable-decoder=atrac3,pcm_s16le --enable-encoder=pcm_s16le
--enable-demuxer=wav --enable-muxer=wav --enable-protocol=file,pipe
--enable-filter=aresample,aformat,anull,abuffer,abuffersink --enable-swresample
```

上記の公開ソースと変更内容から、同じものを作り直したり、別の版に差し替えたりできます。
（アプリ本体のコードは公開していません。ここにあるのは同梱ソフトウェアの情報だけです）
